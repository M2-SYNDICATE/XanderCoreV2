from .wakeword import *

__doc__ = wakeword.__doc__
if hasattr(wakeword, "__all__"):
    __all__ = wakeword.__all__